SLYWORD: Game of Dominated — V1 Prototype
================================================

Ce prototype contient déjà un premier socle fonctionnel :
- écran d'accueil avec identité visuelle SLYWORD
- Nouvelle partie / Continuer
- sauvegarde locale automatique
- tablette d'aide à la nouvelle partie
- français / anglais
- son activable/désactivable
- capital initial de 10 000 SLY
- calendrier Janvier 2026
- 1 tour = 1 jour, 20 jours = 1 mois, 6 mois = 1 année
- premier tableau de bord

Pour tester :
1. Ouvrir index.html dans un navigateur.
2. Sur téléphone, le fichier peut être ouvert dans un navigateur compatible.
3. Pour publier sur le Web, téléverser index.html et le dossier assets sur un hébergeur statique.

Les systèmes économiques complets (produits, IA, magasins, investisseur, employés, espionnage, sabotage, etc.) seront ajoutés dans les prochaines étapes.
